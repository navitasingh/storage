const express=require('express');

const app=express();

var file=require('fs');
//help to decode json file
var appparser=require('body-parser');
app.use(appparser.json());
// Add headers
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});
app.get('/',function(req,res){
    res.send("Welcome to express JS.....");

});
app.get('/getallCourses',function(req,res){
    file.readFile('Courses.json','utf-8',function(err,data){
        if(err){
            res.send("Error in reading file");
        }else{
            res.send(data);
        }
    });
    //res.send("Dislay all employee");
});
//search duration on the basis of name
app.get('/getDuration/:cname',function(req,res){
    var name=req.params.cname;
    
    file.readFile('Courses.json','utf-8',function(err,data){
        if(err){
            res.send("Error in reading file");
        }else{
           let check=false;
            let myAllData=JSON.parse(data);
                for(let i of  myAllData)
                {
                    if(i.name==name)
                    {
                       let obj= {"duration":i.duration}
                     check=true;
                       res.send(obj);
                        break;
                    }
                 
                
                }
                

                if(!check){
                    let obj= {"duration":"No Courses found In the List"}
                  
                      res.send(obj);
                }

        }
    });
    
});





// to add

app.post('/createCourse/',function(req,res){
    
 file.readFile('Courses.json','utf-8',function(err,data){
     if(err){
         res.send("Error in reading");
     }
     else{

         var myAllData=[];
         myAllData=JSON.parse(data);
         var i=myAllData.length;
         console.log(i);
             var mydata={
            "id":i,
            "name":req.body.name,
            "price":'0',
             "duration":req.body.duration
         }
         myAllData.push(mydata);

         
         var javaJson=JSON.stringify(myAllData);
         
         file.writeFile('Courses.json',javaJson,function(err,data){
             if(err){
                 res.send("Error in writing");
             }
             else{
                 let obj= {"temp":javaJson}//new
                 res.send(obj);
                 obj={};
             }
         });
     }
 });
 });


app.listen(9880,function(err,res){
console.log("Running on port 9880.....");
});