import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CoursesDataService {

  constructor(private httpService: HttpClient) { }

  getCoursesFromJson()
  {
       return this.httpService.get('http://localhost:9880/getallCourses');
  }

  getDuration(data:any){
    let a = this.httpService.get('http://localhost:9880/getDuration/'+data);
    return a;
 }

 addData(temp:any){
  let a = this.httpService.post("http://localhost:9880/createCourse/",temp);
  return a;
}
}


