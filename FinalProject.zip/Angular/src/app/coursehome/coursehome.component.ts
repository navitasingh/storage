import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coursehome',
  templateUrl: './coursehome.component.html',
  styleUrls: ['./coursehome.component.css']
})
export class CoursehomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
