import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';


import { CoursehomeComponent } from './coursehome.component';

describe('CoursehomeComponent', () => {

  
  let injector: TestBed;
  let httpMock: HttpTestingController;

  let component: CoursehomeComponent;
  let fixture: ComponentFixture<CoursehomeComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      declarations: [ CoursehomeComponent ]
    })
    .compileComponents();

    injector = getTestBed();
    httpMock = injector.get(HttpTestingController);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoursehomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
