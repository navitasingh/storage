import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { CoursesDataService } from './courses-data-service.service';

describe('CoursesDataService', () => {

  let injector: TestBed;
  let service: CoursesDataService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      providers: [CoursesDataService]
    });

    injector = getTestBed();
    service = injector.get(CoursesDataService);
    httpMock = injector.get(HttpTestingController);

  });

  it('should be created', inject([CoursesDataService], (service: CoursesDataService) => {
    expect(service).toBeTruthy();
  }));
});



