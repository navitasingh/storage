import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { CoursesListComponent } from './courses-list.component';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';


describe('CoursesListComponent', () => {

  let injector: TestBed;
  let httpMock: HttpTestingController;

  let component: CoursesListComponent;
  let fixture: ComponentFixture<CoursesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoursesListComponent ]
    })
    .compileComponents();

    injector = getTestBed();
    httpMock = injector.get(HttpTestingController);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoursesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
