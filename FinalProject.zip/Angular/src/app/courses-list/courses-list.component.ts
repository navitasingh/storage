import { Component, OnInit } from '@angular/core';
import { CoursesFormat } from '../coursesFormat';
import { CoursesDataService } from 'src/app/courses-data-service.service';

@Component({
  selector: 'app-courses-list',
  templateUrl: './courses-list.component.html',
  styleUrls: ['./courses-list.component.css'],
  providers: [CoursesDataService]
})
export class CoursesListComponent implements OnInit {
  
  coursesArray:CoursesFormat[];
  temp:any={};
  datatoSearch:any;
  cSearchDuration: number;
  ErrMsg:string;
  boolValue:boolean = true;
  flag:boolean =false;

  constructor(private _coursesjson:CoursesDataService) { }
  ngOnInit() {
    this._coursesjson.getCoursesFromJson().subscribe(data => {
      this.coursesArray = data as CoursesFormat[]
    });
  }

  addData(){
    this.flag = false;
    for(let data of this.coursesArray)
   {
     let a =  data.name.toLowerCase();
      let b = this.temp.name.toLowerCase();
      if(a == b){
        this.flag = true;
        break;
      }
    }

    if(!this.flag){
      
      this._coursesjson.addData(this.temp).subscribe((data:CoursesFormat)=>{
        this._coursesjson.getCoursesFromJson().subscribe(data => {
          this.coursesArray = data as CoursesFormat[]
        });
        // this.temp={};
       });
    } else {
      this.ErrMsg = 'Course already Exists';
      alert(this.ErrMsg);
    }
}

  callSearch(){
    if(this.datatoSearch!=0){
        this._coursesjson.getDuration(this.datatoSearch).subscribe((data:CoursesFormat)=>{
            if(data.id!=this.datatoSearch ){
                this.cSearchDuration = data.duration;
                this.boolValue = false; 
            }
        })}
     
}
}



