import { Component, OnInit } from '@angular/core';
import { CoursesDataService } from '../courses-data-service.service';
import { CoursesFormat } from '../coursesFormat';

@Component({
  selector: 'app-courseswith-json',
  templateUrl: './courseswith-json.component.html',
  styleUrls: ['./courseswith-json.component.css']
})
export class CourseswithJsonComponent implements OnInit {

  coursesArray:CoursesFormat[];

  constructor(private _coursesjson:CoursesDataService) { }

  ngOnInit() {
    this._coursesjson.getCoursesFromJson().subscribe((data:CoursesFormat[]) => this.coursesArray=data);
  }

}
