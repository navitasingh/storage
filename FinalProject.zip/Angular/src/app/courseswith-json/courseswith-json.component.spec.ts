import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';


import { CourseswithJsonComponent } from './courseswith-json.component';

describe('CourseswithJsonComponent', () => {

  let injector: TestBed;
  let httpMock: HttpTestingController;

  let component: CourseswithJsonComponent;
  let fixture: ComponentFixture<CourseswithJsonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      declarations: [ CourseswithJsonComponent ]
    })
    .compileComponents();

    injector = getTestBed();
    httpMock = injector.get(HttpTestingController);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseswithJsonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
