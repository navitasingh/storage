
export class CoursesFormat
{
    id:number;
    name:string;
    duration:number;
    price:number;
}